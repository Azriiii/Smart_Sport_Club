#include "Stat.h"
#include "ui_Stat.h"


QT_CHARTS_USE_NAMESPACE

Stat::Stat(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Stat)
{
    ui->setupUi(this);



    QSqlQuery q1,q2,q3;
    q1.prepare("SELECT COUNT(*) FROM Abonnement WHERE TYPE_ABONNEMENT LIKE 'Loge'");
    q2.prepare("SELECT COUNT(*) FROM Abonnement WHERE TYPE_ABONNEMENT LIKE 'Enceinte'");
    q3.prepare("SELECT COUNT(*) FROM Abonnement WHERE TYPE_ABONNEMENT LIKE 'Gradin'");
    q1.exec();
    q2.exec();
    q3.exec();
    int rows = 0;
    int rows1= 0;
    int rows2= 0;
    if (q1.next()) {
    rows= q1.value(0).toInt();
    }
    if (q2.next()) {
    rows1= q2.value(0).toInt();
    }
    if (q3.next()) {
    rows2= q3.value(0).toInt();
    }
     // Assign names to the set of bars used
     QBarSet *set0 = new QBarSet("Nombre");
     // Assign values for each bar
     *set0 << rows2 << rows1 << rows;
     // Add all sets of data to the chart as a whole
     // 1. Bar Chart
     QBarSeries *series = new QBarSeries();
     series->append(set0);
     // Used to define the bar chart to display, title

     QChart *chart = new QChart();
     // Add the chart
     chart->addSeries(series);

     // Set title
     chart->setTitle("Nombre d'abonnement par Nature");

     // Define starting animation
     // NoAnimation, GridAxisAnimations, SeriesAnimations
     chart->setAnimationOptions(QChart::AllAnimations);

     // Holds the category titles
     QStringList categories;
     categories << "Gradin" << "Enceinte" << "Loge" ;

     // Adds categories to the axes
     QBarCategoryAxis *axis = new QBarCategoryAxis();
     axis->append(categories);
     chart->createDefaultAxes();

     // 1. Bar chart
     chart->setAxisX(axis, series);

     // Define where the legend is displayed
     chart->legend()->setVisible(true);
     chart->legend()->setAlignment(Qt::AlignBottom);

     // Used to display the chart
     QChartView *chartView = new QChartView(chart);
     chartView->setRenderHint(QPainter::Antialiasing);

     // Used to change the palette
     QPalette pal = qApp->palette();

     // Change the color around the chart widget and text
     pal.setColor(QPalette::Window, QRgb(0xffffff));
     pal.setColor(QPalette::WindowText, QRgb(0x404044));

     // Apply palette changes to the application
     qApp->setPalette(pal);

     // Create the main app window
     chartView->setParent(ui->horizontalFrame);
}

Stat::~Stat()
{
    delete ui;
}
