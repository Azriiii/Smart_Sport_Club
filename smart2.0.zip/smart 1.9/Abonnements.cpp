#include "Abonnements.h"

Abonnements::Abonnements()
{
    Id=0;

    Code="";
    Nature="";
}

Abonnements::Abonnements(int id,QString code,QString nature)
{
    this->Id=id;

    this->Code=code;
    this->Nature=nature;
}

int Abonnements::get_Id(){return Id;}

QString Abonnements::get_Code(){return Code;}
QString Abonnements::get_Nature(){return Nature;}

bool Abonnements::Ajouter_Abonnement()
{
QSqlQuery query;
QString res= QString::number(Id);
query.prepare("INSERT INTO Abonnement (Id,  Code, TYPE_ABONNEMENT) "
                    "VALUES (:Id,  :Code, :Nature)");
query.bindValue(":Id", res);

query.bindValue(":Code", Code);
query.bindValue(":Nature", Nature);

return    query.exec();
}

QSqlQueryModel * Abonnements::Afficher_Abonnement()
{
    QSqlQueryModel * model= new QSqlQueryModel();

model->setQuery("select * from Abonnement");
model->setHeaderData(0, Qt::Horizontal, QObject::tr("Id"));

model->setHeaderData(3, Qt::Horizontal, QObject::tr("Code"));
model->setHeaderData(4, Qt::Horizontal, QObject::tr("Nature"));
    return model;
}

bool Abonnements::Supprimer_Abonnement()
{
QSqlQuery query;
QString res= QString::number(Id);
query.prepare("DELETE FROM Abonnement WHERE Id = :Id ");
query.bindValue(":Id", res);
return    query.exec();
}


bool Abonnements::Modifier_uitlisateur()
{
    QSqlQuery query ;
    QString res=QString::number(Id);
    query.prepare("Update Abonnement set  Code=:Code,TYPE_ABONNEMENT=:Nature where Id=:Id ");
            query.bindValue(":Id",res);

            query.bindValue(":Code", Code);
            query.bindValue(":Nature", Nature);
            return query.exec();
}





QSqlQueryModel* Abonnements::Tri_Abonnement_Nature()
{
    QSqlQueryModel* model =new QSqlQueryModel();
     QSqlQuery  *r = new QSqlQuery();
     r->prepare("SELECT * FROM Abonnement ORDER BY TYPE_ABONNEMENT DESC ");
     r->exec();
     model->setQuery(*r);
     return model ;
}

QSqlQueryModel* Abonnements::Rechercher_Abonnement(const QString &str)
{
    QSqlQueryModel * model=new QSqlQueryModel() ;
    QSqlQuery q;
q.prepare("SELECT * FROM Abonnement where (Id LIKE '"+str+"%' OR Code LIKE '"+str+"%' OR TYPE_ABONNEMENT LIKE '"+str+"%')")  ;
q.exec() ;
model->setQuery(q);
return model;
}

