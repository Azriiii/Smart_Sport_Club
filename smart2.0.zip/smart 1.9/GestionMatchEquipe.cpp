#include "GestionMatchEquipe.h"
#include "ui_GestionMatchEquipe.h"
#include "match.h"
#include "menu.h"
#include "equipe.h"
#include "QMessageBox"
#include <QPainter>
#include <QDesktopServices>
#include <QUrl>
#include "smtp.h"
#include <QString>
#include <QDate>
#include <QPdfWriter>
#include <QPrinter>
#include <QPrinter>
#include <QPainter>
#include <QPrintDialog>
#include <QPieSlice>
#include <QPieSeries>
#include <QtCharts/QChartView>
#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtCharts/QBarSeries>
#include <QtCharts/QBarSet>
#include <QtCharts/QLegend>
QT_CHARTS_USE_NAMESPACE
#include <QTextStream>


GestionMatchEquipe::GestionMatchEquipe(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::GestionMatchEquipe)
{

    ui->setupUi(this);
    ui->data->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->data_2->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->DATE->setDate(QDate::currentDate());
    match tmp;
    equipe tmp2;
    ui->id_equipe1->setModel(tmp2.getIDs());
    ui->id_equipe2->setModel(tmp2.getIDs());
    ui->data_2->setModel(tmp2.afficher());
    ui->id_match->setModel(tmp.getIDs());
    //connect(ui->send, SIGNAL(clicked()),this, SLOT(sendMail()));
}

GestionMatchEquipe::~GestionMatchEquipe()
{
    delete ui;
}


void GestionMatchEquipe::on_pb_ajouter_clicked()
{
 match tmp(ui->id_match2->text().toInt(),ui->lieu->text(),ui->id_equipe1->currentText().toInt(),ui->id_equipe2->currentText().toInt(),ui->DATE->date());


    if (ui->id_match2->text().isEmpty())
    {
              QMessageBox::information(this," ERREUR "," Verifier le champ ID MATCH !") ;
    }
     else if (ui->lieu->text().isEmpty())
     {
              QMessageBox::information(this," ERREUR "," Verifier le champ LIEU !") ;

     }



    else if(tmp.ajouter())
    {

        ui->data->setModel(tmp.afficher());
        ui->lineEdit_id_6->setText("");
        ui->id_match->setModel(tmp.getIDs());
        QMessageBox::information(nullptr, QObject::tr("Ajout"),
                          QObject::tr("Success.\n"
                                      "Click Cancel to exit."), QMessageBox::Cancel);
    }
    else
    {
        QMessageBox::information(nullptr, QObject::tr("Ajout"),
                          QObject::tr("Erreur.\n"
                                      "Click Cancel to exit."), QMessageBox::Cancel);
    }

}

void GestionMatchEquipe::on_pb_supprimer_3_clicked()
{
    if(ui->data->currentIndex().row()==-1)
        QMessageBox::information(nullptr, QObject::tr("Modification"),
                          QObject::tr("Veuillez Choisir un Match du Tableau.\n"
                                      "Click Cancel to exit."), QMessageBox::Cancel);
    else
    {
        match tmp(ui->data->model()->data(ui->data->model()->index(ui->data->currentIndex().row(),0)).toInt(),ui->lieu->text(),ui->id_equipe1->currentText().toInt(),ui->id_equipe2->currentText().toInt(),ui->DATE->date());
        if(tmp.modifier())
        {
            ui->data->setModel(tmp.afficher());
            ui->lineEdit_id_6->setText("");
            ui->id_match->setModel(tmp.getIDs());
            QMessageBox::information(nullptr, QObject::tr("Modification"),
                              QObject::tr("Success.\n"
                                          "Click Cancel to exit."), QMessageBox::Cancel);
        }
        else
        {
            QMessageBox::information(nullptr, QObject::tr("Modification"),
                              QObject::tr("Erreur.\n"
                                          "Click Cancel to exit."), QMessageBox::Cancel);
        }
    }

}

void GestionMatchEquipe::on_pb_supprimer_4_clicked()
{

    if(ui->data->currentIndex().row()==-1)
        QMessageBox::information(nullptr, QObject::tr("Suppression"),
                          QObject::tr("Veuillez Choisir un Match du Tableau.\n"
                                      "Click Cancel to exit."), QMessageBox::Cancel);
    else
    {
        match tmp(ui->data->model()->data(ui->data->model()->index(ui->data->currentIndex().row(),0)).toInt(),ui->lieu->text(),ui->id_equipe1->currentText().toInt(),ui->id_equipe2->currentText().toInt(),ui->DATE->date());
        if(tmp.supprimer())
        {
            ui->data->setModel(tmp.afficher());
            ui->lineEdit_id_6->setText("");
            ui->id_match->setModel(tmp.getIDs());
            QMessageBox::information(nullptr, QObject::tr("Suppression"),
                              QObject::tr("Success.\n"
                                          "Click Cancel to exit."), QMessageBox::Cancel);
        }
        else
        {
            QMessageBox::information(nullptr, QObject::tr("Suppression"),
                              QObject::tr("Erreur.\n"
                                          "Click Cancel to exit."), QMessageBox::Cancel);
        }
    }

}

void GestionMatchEquipe::on_data_clicked(const QModelIndex &index)
{
    ui->id_match2->setText(ui->data->model()->data(ui->data->model()->index(ui->data->currentIndex().row(),0)).toString());
    ui->lieu->setText(ui->data->model()->data(ui->data->model()->index(ui->data->currentIndex().row(),1)).toString());
    ui->id_equipe1->setCurrentText(ui->data->model()->data(ui->data->model()->index(ui->data->currentIndex().row(),2)).toString());
    ui->id_equipe2->setCurrentText(ui->data->model()->data(ui->data->model()->index(ui->data->currentIndex().row(),3)).toString());

    ui->DATE->setDate(ui->data->model()->data(ui->data->model()->index(ui->data->currentIndex().row(),4)).toDate());

}

void GestionMatchEquipe::on_lineEdit_id_6_textChanged(const QString &arg1)
{

     match tmp;
     if(ui->lineEdit_id_6->text()!="")
     {

         QString b=ui->comboBox->currentText();
         QString a=ui->lineEdit_id_6->text();
         ui->data->setModel(tmp.displayClause("WHERE ("+b+" LIKE '%"+a+"%')"));
     }else
     ui->data->setModel(tmp.afficher());
}

void GestionMatchEquipe::on_comboBox_currentTextChanged(const QString &arg1)
{
    match tmp;
    if(ui->lineEdit_id_6->text()!="")
    ui->data->setModel(tmp.displayClause("WHERE "+ui->comboBox->currentText()+"="+ui->lineEdit_id_6->text()+" ORDER BY "+ui->id_tri->currentText()));
    else
    ui->data->setModel(tmp.afficher());
}



void GestionMatchEquipe::on_pb_ajouter_2_clicked()
{
    equipe tmp(ui->id_equipe->text().toInt(),ui->NOM->text(),ui->division->text(),ui->id_match->currentText().toInt(),ui->type->text(),ui->mail_equipe->text());

    if (ui->id_equipe->text().isEmpty())
    {

              QMessageBox::information(this," ERREUR "," Verifier le champ ID EQUIPE !") ;

    } else if (ui->NOM->text().isEmpty())
     {
              QMessageBox::information(this," ERREUR "," Verifier le champ NOM !") ;

     }
   else if (ui->division->text().isEmpty())
    {
              QMessageBox::information(this," ERREUR "," Verifier le champ DIVISION !") ;
    }
     else if (ui->type->text().isEmpty())
     {
              QMessageBox::information(this," ERREUR "," Verifier le champ TYPE !") ;

     }
    else if (ui->mail_equipe->text().isEmpty())
    {
             QMessageBox::information(this," ERREUR "," Verifier le champ EMAIL !") ;

    }



   else if(tmp.ajouter())
    {
        ui->data_2->setModel(tmp.afficher());
        ui->lineEdit_id_7->setText("");
        ui->id_equipe1->setModel(tmp.getIDs());
        ui->id_equipe2->setModel(tmp.getIDs());
        QMessageBox::information(nullptr, QObject::tr("Ajout"),
                          QObject::tr("Success.\n"
                                      "Click Cancel to exit."), QMessageBox::Cancel);
    }
    else
    {
        QMessageBox::information(nullptr, QObject::tr("Ajout"),
                          QObject::tr("Erreur.\n"
                                      "Click Cancel to exit."), QMessageBox::Cancel);
    }
}

void GestionMatchEquipe::on_pb_supprimer_5_clicked()
{
    if(ui->data_2->currentIndex().row()==-1)
        QMessageBox::information(nullptr, QObject::tr("Modification"),
                          QObject::tr("Veuillez Choisir un match du tableau.\n"
                                      "Click Cancel to exit."), QMessageBox::Cancel);
    else
    {
        equipe tmp(ui->data_2->model()->data(ui->data_2->model()->index(ui->data_2->currentIndex().row(),0)).toInt(),ui->NOM->text(),ui->division->text(),ui->id_match->currentText().toInt(),ui->type->text(),ui->mail_equipe->text());
        if(tmp.modifier())
        {
            ui->data_2->setModel(tmp.afficher());
            ui->lineEdit_id_7->setText("");
            ui->id_equipe1->setModel(tmp.getIDs());
            ui->id_equipe2->setModel(tmp.getIDs());

            QMessageBox::information(nullptr, QObject::tr("Modification"),
                              QObject::tr("Success.\n"
                                          "Click Cancel to exit."), QMessageBox::Cancel);
        }
        else
        {
            QMessageBox::information(nullptr, QObject::tr("Modification"),
                              QObject::tr("Erreur.\n"
                                          "Click Cancel to exit."), QMessageBox::Cancel);
        }
    }
}

void GestionMatchEquipe::on_pb_supprimer_6_clicked()
{
    if(ui->data_2->currentIndex().row()==-1)
        QMessageBox::information(nullptr, QObject::tr("Suppression"),
                          QObject::tr("Veuillez Choisir un equipe du tableau.\n"
                                      "Click Cancel to exit."), QMessageBox::Cancel);
    else
    {
        equipe tmp(ui->data_2->model()->data(ui->data_2->model()->index(ui->data_2->currentIndex().row(),0)).toInt(),ui->NOM->text(),ui->division->text(),ui->id_match->currentText().toInt(),ui->type->text(),ui->mail_equipe->text());
        if(tmp.supprimer())
        {
            ui->data_2->setModel(tmp.afficher());
            ui->lineEdit_id_7->setText("");
            ui->id_equipe1->setModel(tmp.getIDs());
            ui->id_equipe2->setModel(tmp.getIDs());

            QMessageBox::information(nullptr, QObject::tr("Suppression"),
                              QObject::tr("Success.\n"
                                          "Click Cancel to exit."), QMessageBox::Cancel);
        }
        else
        {
            QMessageBox::information(nullptr, QObject::tr("Suppression"),
                              QObject::tr("Erreur.\n"
                                          "Click Cancel to exit."), QMessageBox::Cancel);
        }
    }
}

void GestionMatchEquipe::on_lineEdit_id_7_textChanged(const QString &arg1)
{
    equipe tmp;
    if(ui->lineEdit_id_7->text()!="")
    {
   // ui->data_2->setModel(tmp.displayClause("WHERE "+ui->comboBox_2->currentText()+"='"+ui->lineEdit_id_7->text()+"' ORDER BY "+ui->id_tri2->currentText()));
        QString b=ui->comboBox_2->currentText();
        QString a=ui->lineEdit_id_7->text();
        ui->data_2->setModel(tmp.displayClause("WHERE ("+b+" LIKE '%"+a+"%')"));
    }else
    ui->data_2->setModel(tmp.afficher());
}




void GestionMatchEquipe::on_comboBox_2_currentTextChanged(const QString &arg1)
{
    equipe tmp;
    if(ui->lineEdit_id_7->text()!="")
    ui->data_2->setModel(tmp.displayClause("WHERE "+ui->comboBox_2->currentText()+"='"+ui->lineEdit_id_7->text()+"' ORDER BY "+ui->id_tri2->currentText()));
    else
    ui->data_2->setModel(tmp.afficher());
}

void GestionMatchEquipe::on_data_2_clicked(const QModelIndex &index)
{
    ui->id_equipe->setText(ui->data_2->model()->data(ui->data_2->model()->index(ui->data_2->currentIndex().row(),0)).toString());
    ui->NOM->setText(ui->data_2->model()->data(ui->data_2->model()->index(ui->data_2->currentIndex().row(),1)).toString());
    ui->division->setText(ui->data_2->model()->data(ui->data_2->model()->index(ui->data_2->currentIndex().row(),2)).toString());
    ui->id_match->setCurrentText(ui->data_2->model()->data(ui->data_2->model()->index(ui->data_2->currentIndex().row(),3)).toString());
    ui->type->setText(ui->data_2->model()->data(ui->data_2->model()->index(ui->data_2->currentIndex().row(),4)).toString());
    ui->mail_equipe->setText(ui->data_2->model()->data(ui->data_2->model()->index(ui->data_2->currentIndex().row(),5)).toString());

}


void GestionMatchEquipe::on_id_tri_currentTextChanged(const QString &arg1)
{
    match tmp;
    if(ui->lineEdit_id_6->text()!="")
    ui->data->setModel(tmp.displayClause("WHERE "+ui->comboBox->currentText()+"="+ui->lineEdit_id_6->text()+" ORDER BY "+ui->id_tri->currentText()));
    else
    ui->data->setModel(tmp.displayClause("ORDER BY "+ui->id_tri->currentText()));
}

void GestionMatchEquipe::on_id_tri2_currentTextChanged(const QString &arg1)
{
    equipe tmp;
    if(ui->lineEdit_id_7->text()!="")
    ui->data_2->setModel(tmp.displayClause("WHERE "+ui->comboBox_2->currentText()+"='"+ui->lineEdit_id_7->text()+"' ORDER BY "+ui->id_tri2->currentText()));
    else
    ui->data_2->setModel(tmp.displayClause("ORDER BY "+ui->id_tri2->currentText()));
}

void GestionMatchEquipe::on_pushButton_2_clicked()
{
    {
         //QDateTime datecreation = date.currentDateTime();
        //QString afficheDC = "Date de Creation PDF : " + datecreation.toString() ;
                       QPdfWriter pdf("C:/Users/Rafik/Desktop/match.pdf");
                       QPainter painter(&pdf);
                      int i = 4000;
                           painter.setPen(Qt::blue);
                           painter.setFont(QFont("Arial", 30));
                           painter.drawText(1500,1400,"Liste Des match");
                           painter.setPen(Qt::black);
                           painter.setFont(QFont("Arial", 15));
                          // painter.drawText(1100,2000,afficheDC);
                           painter.drawRect(100,100,7300,2600);
                           //painter.drawPixmap(QRect(7600,70,2000,2600),QPixmap("C:/Users/Rafik/Desktop/img.jpg"));
                           painter.drawRect(0,3000,9600,500);
                           painter.setFont(QFont("Arial", 9));
                           painter.drawText(300,3300,"ID MATCH");
                           painter.drawText(2300,3300,"LIEU");
                           painter.drawText(4300,3300,"ID EQUIPE1");
                           painter.drawText(6300,3300,"ID EQUIPE2");
                           painter.drawText(8300,3300,"DATE");
                           QSqlQuery query;
                           query.prepare("select * from match");
                           query.exec();
                           while (query.next())
                           {
                               painter.drawText(300,i,query.value(0).toString());
                               painter.drawText(2300,i,query.value(1).toString());
                               painter.drawText(4500,i,query.value(2).toString());
                               painter.drawText(6500,i,query.value(3).toString());
                               painter.drawText(8000,i,query.value(4).toString());
                              i = i + 500;
                           }
                           int reponse = QMessageBox::question(this, "Génerer PDF", "<PDF Enregistré>...Vous Voulez Affichez Le PDF ?", QMessageBox::Yes |  QMessageBox::No);
                               if (reponse == QMessageBox::Yes)
                               {

                                   QDesktopServices::openUrl(QUrl::fromLocalFile("C:/Users/Rafik/Desktop/match.pdf"));

                                   painter.end();
                               }
                               if (reponse == QMessageBox::No)
                               {
                                    painter.end();
                               }
        }

}




void GestionMatchEquipe::on_pushButton_33_clicked()
{
    {
         //QDateTime datecreation = date.currentDateTime();
        //QString afficheDC = "Date de Creation PDF : " + datecreation.toString() ;
                       QPdfWriter pdf("C:/Users/Rafik/Desktop/equipe.pdf");
                       QPainter painter(&pdf);
                      int i = 4000;
                           painter.setPen(Qt::blue);
                           painter.setFont(QFont("Arial", 30));
                           painter.drawText(1500,1400,"Liste Des equipe");
                           painter.setPen(Qt::black);
                           painter.setFont(QFont("Arial", 15));
                          // painter.drawText(1100,2000,afficheDC);
                           painter.drawRect(100,100,7300,2600);
                           //painter.drawPixmap(QRect(7600,70,2000,2600),QPixmap("C:/Users/Rafik/Desktop/img.jpg"));
                           painter.drawRect(0,3000,9600,500);
                           painter.setFont(QFont("Arial", 9));
                           painter.drawText(300,3300,"ID EQUIPE");
                           painter.drawText(2300,3300,"NOM");
                           painter.drawText(4300,3300,"DIVISION");
                           painter.drawText(6300,3300,"ID MATCH");
                           painter.drawText(8300,3300,"TYPE");
                           painter.drawText(10300,3300,"EMAIL");

                           QSqlQuery query;
                           query.prepare("select * from equipe");
                           query.exec();
                           while (query.next())
                           {
                               painter.drawText(300,i,query.value(0).toString());
                               painter.drawText(2300,i,query.value(1).toString());
                               painter.drawText(4500,i,query.value(2).toString());
                               painter.drawText(6500,i,query.value(3).toString());
                               painter.drawText(8000,i,query.value(4).toString());
                               painter.drawText(8000,i,query.value(5).toString());

                              i = i + 500;
                           }
                           int reponse = QMessageBox::question(this, "Génerer PDF", "<PDF Enregistré>...Vous Voulez Affichez Le PDF ?", QMessageBox::Yes |  QMessageBox::No);
                               if (reponse == QMessageBox::Yes)
                               {

                                   QDesktopServices::openUrl(QUrl::fromLocalFile("C:/Users/Rafik/Desktop/equipe.pdf"));

                                   painter.end();
                               }
                               if (reponse == QMessageBox::No)
                               {
                                    painter.end();
                               }
        }
}

void GestionMatchEquipe::on_Statistique_clicked()
{

    QSqlQueryModel * model= new QSqlQueryModel();
                model->setQuery("select EXTRACT(MONTH FROM DATEE) from MATCH where EXTRACT(MONTH FROM DATEE) between 1 and 4  ");
                float salaire=model->rowCount();
                model->setQuery("select EXTRACT(MONTH FROM DATEE) from MATCH where EXTRACT(MONTH FROM DATEE) between 5 and 8  ");
                float salairee=model->rowCount();
                model->setQuery("select EXTRACT(MONTH FROM DATEE) from MATCH where EXTRACT(MONTH FROM DATEE) between 9 and 12  ");
                float salaireee=model->rowCount();
                float total=salaire+salairee+salaireee;
                QString a=QString("Matches entre Janvier et Avril "+QString::number((salaire*100)/total,'f',2)+"%" );
                QString b=QString("Matches entre Mai et Aout"+QString::number((salairee*100)/total,'f',2)+"%" );
                QString c=QString("Matches entre Septembre et Decembre"+QString::number((salaireee*100)/total,'f',2)+"%" );
                QPieSeries *series = new QPieSeries();
                series->append(a,salaire);
                series->append(b,salairee);
                series->append(c,salaireee);
        if (salaire!=0)
        {QPieSlice *slice = series->slices().at(0);
         slice->setLabelVisible();
         slice->setPen(QPen());}
        if ( salairee!=0)
        {
                 // Add label, explode and define brush for 2nd slice
                 QPieSlice *slice1 = series->slices().at(1);
                 //slice1->setExploded();
                 slice1->setLabelVisible();
        }
        if(salaireee!=0)
        {
                 // Add labels to rest of slices
                 QPieSlice *slice2 = series->slices().at(2);
                 //slice1->setExploded();
                 slice2->setLabelVisible();
        }
                // Create the chart widget
                QChart *chart = new QChart();
                // Add data to chart with title and hide legend
                chart->addSeries(series);
                chart->setTitle("Pourcentage Par Mois:totale de "+ QString::number(total));
                chart->legend()->hide();
                // Used to display the chart
                QChartView *chartView = new QChartView(chart);
                chartView->setRenderHint(QPainter::Antialiasing);
                chartView->resize(1000,500);
                chartView->show();


    }
void GestionMatchEquipe::sendMail()
{
    QString  nom = ui->NOM->text();
    QString  id = ui->id_equipe->text();
    QString  idm = ui->id_match->currentText();
    QString  lieu = ui->lieu->text();
    QDate    datee = ui->DATE->date();
    QString dateString = datee.toString();
           //QString dateString = ui->DATE->toString();

    Smtp* smtp = new Smtp("espritcovid2020@gmail.com", "rafik123456789", "smtp.gmail.com",465);
    connect(smtp, SIGNAL(status(QString)), this, SLOT(mailSent(QString)));

    smtp->sendMail("espritcovid2020@gmail.com", ui->mail_equipe->text() ,"Match","Bonjour "+nom+" votre Equipe ID est "+id+" et Votre match sera le  "+dateString+" en "+lieu+" et votre Match ID est "+idm);
}


void GestionMatchEquipe::mailSent(QString status)
{
    if(status == "Message sent")
        QMessageBox::warning( nullptr, tr( "Qt Simple SMTP client" ), tr( "Message sent!\n\n" ) );
}



void GestionMatchEquipe::on_pushButton24_clicked()
{
        close();
        menu c;
        c.exec();
}

void GestionMatchEquipe::on_pushButton24_2_clicked()
{
    close();
    menu c;
    c.exec();
}
