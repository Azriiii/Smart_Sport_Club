#ifndef GESTIONABOCADEAU_H
#define GESTIONABOCADEAU_H

#include <QMainWindow>
#include "Abonnements.h"
#include "Cadeau.h"
#include "Stat.h"

namespace Ui {
class gestionabocadeau;
}

class gestionabocadeau : public QMainWindow
{
    Q_OBJECT

public:
    explicit gestionabocadeau(QWidget *parent = nullptr);
    ~gestionabocadeau();

private slots:
    void on_Gestion_Abonnements_clicked();

    void on_Retour_Abonnement_clicked();

    void on_Ajouter_Abonnement_clicked();

    void on_Modifier_Abonnement_clicked();

    void on_Supprimer_Abonnement_clicked();

    void on_Afficher_Abonnement_clicked();

    void on_TabAbonnement_clicked(const QModelIndex &index);


    void on_Rechercher_Abonnement_textChanged(const QString &arg1);

    void on_Gestion_Cadeau_clicked();

    void on_Retour_Cadeau_clicked();

    void on_Ajouter_Cadeau_clicked();

    void on_Modifier_Cadeau_clicked();

    void on_Supprimer_Cadeau_clicked();

    void on_Afficher_Cadeau_clicked();

    void on_TabCadeau_clicked(const QModelIndex &index);

    void on_Tri_Cadeau_activated(const QString &arg1);

    void on_Retour_Menu_clicked();

    void on_Statistique_clicked();

private:
    Ui::gestionabocadeau *ui;
    Abonnements tmpAbonnement;
    Cadeau tmpCadeau;
    Stat *stat;
};

#endif // GESTIONABOCADEAU_H
