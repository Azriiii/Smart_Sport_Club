#include "Cadeau.h"
#include <QDate>
Cadeau::Cadeau()
{


}


Cadeau::Cadeau(int id, QDate date,int nombre_Cadeau, QString Type)
{
    this->ID=id;
    this->Date=date;
    this->Nombre_Cadeau=nombre_Cadeau;
    this->Type=Type;
}


int Cadeau::get_ID(){return ID;}
QDate Cadeau::get_Date(){return Date;}
int Cadeau::get_NombreCadeau(){return Nombre_Cadeau;}
QString Cadeau::get_Type(){return Type;}


bool Cadeau::Ajouter_Cadeau()
{
QSqlQuery query;
QString res= QString::number(ID);
query.prepare("INSERT INTO Cadeau (ID, DATET, NBCADEAU, TYPE) "
                    "VALUES (:Id, :Date, :NbCadeau, :Type)");
query.bindValue(":Id", res);
query.bindValue(":Date",Date );
query.bindValue(":NbCadeau",Nombre_Cadeau );
query.bindValue(":Type", Type);

return    query.exec();
}

bool Cadeau::Supprimer_Torunois()
{
    QSqlQuery query;
    QString res= QString::number(ID);
    query.prepare("DELETE from Cadeau where ID=:Id");
    query.bindValue(":Id", res);
    return    query.exec();
}

bool Cadeau::Modifier_Cadeau()
{
    QSqlQuery query ;
    QString res=QString::number(ID);
    query.prepare("Update Cadeau set DATET=:date, NBCadeau=:nbCadeau, Type=:Type where ID=:id ");
            query.bindValue(":id",res);
            query.bindValue(":date", Date );
            query.bindValue(":nbCadeau",Nombre_Cadeau);
            query.bindValue(":Type", Type);
            return query.exec();
}


QSqlQueryModel * Cadeau::Afficher_Cadeau()
{
    QSqlQueryModel * model= new QSqlQueryModel();

model->setQuery("select * from Cadeau");
model->setHeaderData(0, Qt::Horizontal, QObject::tr("ID"));
model->setHeaderData(1, Qt::Horizontal, QObject::tr("Date"));
model->setHeaderData(2, Qt::Horizontal, QObject::tr("Nombre d'Cadeau"));
model->setHeaderData(3, Qt::Horizontal, QObject::tr("Type"));
    return model;
}

QSqlQueryModel*  Cadeau::Tri_Cadeau_ID()
{
    QSqlQueryModel* model =new QSqlQueryModel();
     QSqlQuery  *r = new QSqlQuery();
     r->prepare("SELECT * FROM Cadeau ORDER BY ID ASC");
     r->exec();
     model->setQuery(*r);
     return model ;

}

QSqlQueryModel*  Cadeau::Tri_Cadeau_Date()
{
    QSqlQueryModel* model =new QSqlQueryModel();
     QSqlQuery  *r = new QSqlQuery();
     r->prepare("SELECT * FROM Cadeau ORDER BY DATET ASC");
     r->exec();
     model->setQuery(*r);
     return model ;

}

QSqlQueryModel*  Cadeau::Tri_Cadeau_Cadeau()
{
    QSqlQueryModel* model =new QSqlQueryModel();
     QSqlQuery  *r = new QSqlQuery();
     r->prepare("SELECT * FROM Cadeau ORDER BY NBCadeau");
     r->exec();
     model->setQuery(*r);
     return model ;

}

