#ifndef ABONNEMENTS_H
#define ABONNEMENTS_H
#include <QString>
#include <QSqlQuery>
#include <QSqlQueryModel>

class Abonnements
{
private:
    int Id ;

    QString Code ;
    QString Nature ;
public:
    Abonnements();
    Abonnements(int,QString,QString);

    int get_Id ();

    QString get_Code();
    QString get_Nature();

    bool Ajouter_Abonnement();
    bool Modifier_uitlisateur();
    QSqlQueryModel * Afficher_Abonnement () ;
    bool Supprimer_Abonnement();
    bool Login(int,QString);

    QSqlQueryModel * Tri_Abonnement_Nature();
    QSqlQueryModel* Rechercher_Abonnement(const QString &str);




};

#endif // AbonnementS_H
