#include "gestionabocadeau.h"
#include "ui_gestionabocadeau.h"
#include <QObject>
#include <QMessageBox>
#include "Abonnements.h"
#include "Cadeau.h"
#include "menu.h"

gestionabocadeau::gestionabocadeau(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::gestionabocadeau)
{
    ui->setupUi(this);
    ui->comboBox->addItem("Gradin");
    ui->comboBox->addItem("Enceinte");
    ui->comboBox->addItem("Loge");
}

gestionabocadeau::~gestionabocadeau()
{
    delete ui;
}

void gestionabocadeau::on_Gestion_Abonnements_clicked()
{
    ui->stackedWidget->setCurrentIndex(1);
}

void gestionabocadeau::on_Retour_Abonnement_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
}

void gestionabocadeau::on_Ajouter_Abonnement_clicked()
{
    int Id =ui->Id->text().toInt();

    QString Code= ui->Code->text();
    QString Nature=ui->comboBox->currentText();
  Abonnements u(Id,Code,Nature);
  bool test=u.Ajouter_Abonnement();
  if(test)
{ ui->TabAbonnement->setModel(tmpAbonnement.Afficher_Abonnement());
QMessageBox::information(nullptr, QObject::tr("Ajouter un Abonnement"),
                  QObject::tr("Abonnement ajouté.\n"
                              "Click Cancel to exit."), QMessageBox::Cancel);

}
  else
      QMessageBox::critical(nullptr, QObject::tr("Ajouter un Abonnement"),
                  QObject::tr("Erreur !.\n"
                              "Click Cancel to exit."), QMessageBox::Cancel);
}

void gestionabocadeau::on_Modifier_Abonnement_clicked()
{
    if(ui->TabAbonnement->currentIndex().row()==-1)
        QMessageBox::information(nullptr, QObject::tr("Modification"),
                          QObject::tr("Veuillez Choisir un Abonnement.\n"
                                      "Click Cancel to exit."), QMessageBox::Cancel);
    else
    {
         Abonnements tmp(ui->TabAbonnement->model()->data(ui->TabAbonnement->model()->index(ui->TabAbonnement->currentIndex().row(),0)).toInt(),ui->Code->text(),ui->comboBox->currentText());
        if(tmp.Modifier_uitlisateur())
        {
            ui->TabAbonnement->setModel(tmp.Afficher_Abonnement());

            QMessageBox::information(nullptr, QObject::tr("Modification"),
                              QObject::tr("Success.\n"
                                          "Click Cancel to exit."), QMessageBox::Cancel);
        }
        else
        {
            QMessageBox::information(nullptr, QObject::tr("Modification"),
                              QObject::tr("Erreur.\n"
                                          "Click Cancel to exit."), QMessageBox::Cancel);
        }
    }
}

void gestionabocadeau::on_Supprimer_Abonnement_clicked()
{
    if(ui->TabAbonnement->currentIndex().row()==-1)
        QMessageBox::information(nullptr, QObject::tr("Modification"),
                          QObject::tr("Veuillez Choisir un Abonnement.\n"
                                      "Click Cancel to exit."), QMessageBox::Cancel);
    else
    {
         Abonnements tmp(ui->TabAbonnement->model()->data(ui->TabAbonnement->model()->index(ui->TabAbonnement->currentIndex().row(),0)).toInt(),ui->Code->text(),ui->comboBox->currentText());
        if(tmp.Supprimer_Abonnement())
        {
            ui->TabAbonnement->setModel(tmp.Afficher_Abonnement());

            QMessageBox::information(nullptr, QObject::tr("Modification"),
                              QObject::tr("Success.\n"
                                          "Click Cancel to exit."), QMessageBox::Cancel);
        }
        else
        {
            QMessageBox::information(nullptr, QObject::tr("Modification"),
                              QObject::tr("Erreur.\n"
                                          "Click Cancel to exit."), QMessageBox::Cancel);
        }
    }
}

void gestionabocadeau::on_Afficher_Abonnement_clicked()
{
    ui->TabAbonnement->setModel(tmpAbonnement.Afficher_Abonnement());
}

void gestionabocadeau::on_TabAbonnement_clicked(const QModelIndex &index)
{
    ui->Id->setText(ui->TabAbonnement->model()->data(ui->TabAbonnement->model()->index(ui->TabAbonnement->currentIndex().row(),0)).toString());

    ui->Code->setText(ui->TabAbonnement->model()->data(ui->TabAbonnement->model()->index(ui->TabAbonnement->currentIndex().row(),1)).toString());
    ui->comboBox->setCurrentText(ui->TabAbonnement->model()->data(ui->TabAbonnement->model()->index(ui->TabAbonnement->currentIndex().row(),2)).toString());
}

void gestionabocadeau::on_Rechercher_Abonnement_textChanged(const QString &arg1)
{
    QString str=ui->Rechercher_Abonnement->text();
    QSqlQueryModel* model=tmpAbonnement.Rechercher_Abonnement(str);
        ui->TabAbonnement-> setModel(model);
}

void gestionabocadeau::on_Gestion_Cadeau_clicked()
{
    ui->stackedWidget->setCurrentIndex(2);
}

void gestionabocadeau::on_Retour_Cadeau_clicked()
{
     ui->stackedWidget->setCurrentIndex(0);
}

void gestionabocadeau::on_Ajouter_Cadeau_clicked()
{
    int Id=ui->ID->text().toInt();
    QDate Date=ui->dateEdit->date();
    int NombreCadeau=ui->Nombre_Cadeau->text().toInt();
    QString Type= ui->Type_Cadeau->text();
    Cadeau T(Id,Date,NombreCadeau,Type);
    bool test=T.Ajouter_Cadeau();
    if(test)
  {
        ui->TabCadeau->setModel(tmpCadeau.Afficher_Cadeau());
  QMessageBox::information(nullptr, QObject::tr("Ajouter un Cadeau"),
                    QObject::tr("Cadeau ajouté.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);

  }
    else
        QMessageBox::critical(nullptr, QObject::tr("Ajouter un Cadeau"),
                    QObject::tr("Erreur !.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);
}

void gestionabocadeau::on_Modifier_Cadeau_clicked()
{
    if(ui->TabCadeau->currentIndex().row()==-1)
        QMessageBox::information(nullptr, QObject::tr("Modification Tounrois"),
                          QObject::tr("Veuillez Choisir un Abonnement.\n"
                                      "Click Cancel to exit."), QMessageBox::Cancel);
    else
    {
         Cadeau tmp(ui->TabCadeau->model()->data(ui->TabCadeau->model()->index(ui->TabCadeau->currentIndex().row(),0)).toInt(),ui->dateEdit->date(),ui->Nombre_Cadeau->text().toInt(),ui->Type_Cadeau->text());
        if(tmp.Modifier_Cadeau())
        {
            ui->TabCadeau->setModel(tmp.Afficher_Cadeau());

            QMessageBox::information(nullptr, QObject::tr("Modification"),
                              QObject::tr("Success.\n"
                                          "Click Cancel to exit."), QMessageBox::Cancel);
        }
        else
        {
            QMessageBox::information(nullptr, QObject::tr("Modification"),
                              QObject::tr("Erreur.\n"
                                          "Click Cancel to exit."), QMessageBox::Cancel);
        }
    }
}

void gestionabocadeau::on_Supprimer_Cadeau_clicked()
{
    if(ui->TabCadeau->currentIndex().row()==-1)
        QMessageBox::information(nullptr, QObject::tr("Modification Tounrois"),
                          QObject::tr("Veuillez Choisir un Abonnement.\n"
                                      "Click Cancel to exit."), QMessageBox::Cancel);
    else
    {
         Cadeau tmp(ui->TabCadeau->model()->data(ui->TabCadeau->model()->index(ui->TabCadeau->currentIndex().row(),0)).toInt(),ui->dateEdit->date(),ui->Nombre_Cadeau->text().toInt(),ui->Type_Cadeau->text());
        if(tmp.Supprimer_Torunois())
        {
            ui->TabCadeau->setModel(tmp.Afficher_Cadeau());

            QMessageBox::information(nullptr, QObject::tr("Modification"),
                              QObject::tr("Success.\n"
                                          "Click Cancel to exit."), QMessageBox::Cancel);
        }
        else
        {
            QMessageBox::information(nullptr, QObject::tr("Modification"),
                              QObject::tr("Erreur.\n"
                                          "Click Cancel to exit."), QMessageBox::Cancel);
        }
    }
}

void gestionabocadeau::on_Afficher_Cadeau_clicked()
{
    ui->TabCadeau->setModel(tmpCadeau.Afficher_Cadeau());
}

void gestionabocadeau::on_TabCadeau_clicked(const QModelIndex &index)
{
    ui->ID->setText(ui->TabCadeau->model()->data(ui->TabCadeau->model()->index(ui->TabCadeau->currentIndex().row(),0)).toString());
    ui->dateEdit->setDate(ui->TabCadeau->model()->data(ui->TabCadeau->model()->index(ui->TabCadeau->currentIndex().row(),1)).toDate());
    ui->Nombre_Cadeau->setText(ui->TabCadeau->model()->data(ui->TabCadeau->model()->index(ui->TabCadeau->currentIndex().row(),2)).toString());
    ui->Type_Cadeau->setText(ui->TabCadeau->model()->data(ui->TabCadeau->model()->index(ui->TabCadeau->currentIndex().row(),3)).toString());
}

void gestionabocadeau::on_Tri_Cadeau_activated(const QString &arg1)
{
    QSqlQueryModel* model=tmpCadeau.Tri_Cadeau_ID();
        ui->TabCadeau->setModel(model);
        if(ui->Tri_Cadeau->currentIndex()==1)
        {
            QSqlQueryModel* model=tmpCadeau.Tri_Cadeau_Date();
                ui->TabCadeau->setModel(model);
        }
        else if (ui->Tri_Cadeau->currentIndex()==2)
        {
            QSqlQueryModel* model=tmpCadeau.Tri_Cadeau_Cadeau();
                ui->TabCadeau->setModel(model);
        }
}

void gestionabocadeau::on_Retour_Menu_clicked()
{
    menu w ;
    hide();
    w.exec();
}

void gestionabocadeau::on_Statistique_clicked()
{
    stat = new Stat(this);
    stat->show();
}
