#ifndef Cadeau_H
#define Cadeau_H
#include <QString>
#include <QSqlQuery>
#include <QSqlQueryModel>
#include <QDate>

class Cadeau
{
private:
    int ID ;
    QDate Date ;
    int Nombre_Cadeau ;
    QString Type ;

public:
    Cadeau();
    Cadeau(int,QDate,int,QString);

    int get_ID ();
    QDate get_Date();
    int get_NombreCadeau();
    QString get_Type();

    bool Ajouter_Cadeau();
    bool Modifier_Cadeau();
    QSqlQueryModel * Afficher_Cadeau () ;
    bool Supprimer_Torunois();
    QSqlQueryModel * Tri_Cadeau_ID () ;
    QSqlQueryModel * Tri_Cadeau_Date () ;
    QSqlQueryModel * Tri_Cadeau_Cadeau () ;



};

#endif // Cadeau_H
