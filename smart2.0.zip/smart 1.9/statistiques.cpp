#include "statistiques.h"
#include "ui_statistiques.h"
#include "doncontroller.h"

Statistiques::Statistiques(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Statistiques)
{
    ui->setupUi(this);
    DonController tmpDon;
    int rows = tmpDon.count("MONTANT_DON < 1000");
    int rows1= tmpDon.count("MONTANT_DON >= 1000 AND MONTANT_DON < 2000");
    int rows2= tmpDon.count("MONTANT_DON >= 2000");
     // Assign names to the set of bars used
     QBarSet *set0 = new QBarSet("Nombre");
     // Assign values for each bar
     *set0 << rows2 << rows1 << rows;
     // Add all sets of data to the chart as a whole
     // 1. Bar Chart
     QBarSeries *series = new QBarSeries();
     series->append(set0);
     // Used to define the bar chart to display, title

     QChart *chart = new QChart();
     // Add the chart
     chart->addSeries(series);

     // Set title
     chart->setTitle("Nombre des Dons par Montant");

     // Define starting animation
     // NoAnimation, GridAxisAnimations, SeriesAnimations
     chart->setAnimationOptions(QChart::AllAnimations);

     // Holds the category titles
     QStringList categories;
     categories << "sup 2000" << "entre 1000 et 2000" << "inf 1000" ;

     // Adds categories to the axes
     QBarCategoryAxis *axis = new QBarCategoryAxis();
     axis->append(categories);
     chart->createDefaultAxes();

     // 1. Bar chart
     chart->setAxisX(axis, series);

     // Define where the legend is displayed
     chart->legend()->setVisible(true);
     chart->legend()->setAlignment(Qt::AlignBottom);

     // Used to display the chart
     QChartView *chartView = new QChartView(chart);
     chartView->setRenderHint(QPainter::Antialiasing);

     // Used to change the palette
     QPalette pal = qApp->palette();

     // Change the color around the chart widget and text
     pal.setColor(QPalette::Window, QRgb(0xffffff));
     pal.setColor(QPalette::WindowText, QRgb(0x404044));

     // Apply palette changes to the application
     qApp->setPalette(pal);

     // Create the main app window
     chartView->setParent(ui->horizontalFrame);
}

Statistiques::~Statistiques()
{
    delete ui;
}
